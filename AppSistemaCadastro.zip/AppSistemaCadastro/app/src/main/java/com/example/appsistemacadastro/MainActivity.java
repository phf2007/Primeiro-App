package com.example.appsistemacadastro;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText edNome, edCpf, edTelefone;
    PessoaDB db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edNome = findViewById(R.id.edNome);
        edCpf = findViewById(R.id.edCpf);
        edTelefone = findViewById(R.id.edTelefone);
        db = new PessoaDB(this);
    }

    public void salvar(View view) {
        String nome = edNome.getText().toString();
        String cpf = edCpf.getText().toString();
        String telefone = edTelefone.getText().toString();

        SQLiteDatabase banco = db.getWritableDatabase();
        ContentValues valores = new ContentValues();
        valores.put("nome", nome);
        valores.put("cpf", cpf);
        valores.put("telefone", telefone);

        banco.insert("pessoas", null, valores);
        banco.close();
    }
}