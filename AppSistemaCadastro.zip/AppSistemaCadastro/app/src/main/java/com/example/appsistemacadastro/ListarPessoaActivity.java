package com.example.appsistemacadastro;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ListarPessoaActivity extends AppCompatActivity {

    ListView lvPessoas;
    PessoaDB db;
    ArrayList<String> lista;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listar_pessoa_activity);

        lvPessoas = findViewById(R.id.lvPessoas);
        db = new PessoaDB(this);

        carregarPessoas();
    }

    public void carregarPessoas() {
        SQLiteDatabase banco = db.getReadableDatabase();
        Cursor cursor = banco.rawQuery("SELECT nome, cpf, telefone FROM pessoas", null);

        lista = new ArrayList<>();

        while (cursor.moveToNext()) {
            String nome = cursor.getString(0);
            String cpf = cursor.getString(1);
            String telefone = cursor.getString(2);
            lista.add(nome + " - " + cpf + " - " + telefone);
        }

        cursor.close();
        banco.close();

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, lista);
        lvPessoas.setAdapter(adapter);
    }
}