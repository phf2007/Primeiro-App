package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    EditText edt1;
    EditText edt2;
    EditText edt3;
    EditText edt5;
    EditText edt6;
    Button btn1;
    TextView txt7;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        edt1 = findViewById((R.id.edt1));
        edt2 = findViewById((R.id.edt2));
        edt3 = findViewById((R.id.edt3));
        edt5 = findViewById((R.id.edt5));
        edt6 = findViewById((R.id.edt6));
        btn1 = findViewById((R.id.btn1));
        txt7 = findViewById((R.id.txt7));
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double km, kml, rs, resultado1, resultado2;
                km=Double.parseDouble(edt3.getText().toString());
                kml=Double.parseDouble(edt5.getText().toString());
                rs=Double.parseDouble(edt6.getText().toString());
                resultado1=km/rs;
                resultado2=resultado1*rs;
                txt7.setText("Combustível necessário é de "+resultado1+" litros, enquanto o custo da viagem será de R$"+resultado2);
            }
        }); {

        }
    }
}