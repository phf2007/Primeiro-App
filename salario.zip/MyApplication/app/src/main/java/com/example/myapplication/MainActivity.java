package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    RadioButton rb1;
    RadioButton rb2;
    RadioButton rb3;
    Button btn1;
    TextView txt1;
    EditText edt1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        edt1 = findViewById((R.id.edt1));
        btn1 = findViewById((R.id.btn1));
        txt1 = findViewById((R.id.txt1));
        rb3 = findViewById((R.id.rb3));
        rb2 = findViewById((R.id.rb2));
        rb1 = findViewById((R.id.rb1));
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Double v1,v2,v3,v4, resultado;
                v1=Double.parseDouble(edt1.getText().toString());
                if (rb1.isChecked()){
                    v2=0.4;
                    resultado=v1*v2;
                    txt1.setText("O seu novo salário é de: R$"+resultado);
                }
                if (rb2.isChecked()){
                    v3=0.45;
                    resultado=v1*v3;
                    txt1.setText("O seu novo salário é de: R$"+resultado);
                }
                if (rb3.isChecked()){
                    v4=0.5;
                    resultado=v1*v4;
                    txt1.setText("O seu novo salário é de: R$"+resultado);
                }
            }
        });

    }
}